package com.example.waithira_jane_s2110907;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import android.renderscript.ScriptGroup;
import android.util.Log;
import java.io.BufferedReader;
import java.io.InputStreamReader;

import android.util.Xml;
import android.widget.TextView;

import java.io.IOException;

// Name                 Jane Waithira
// Student ID           S2110907
// Programme of Study   Mobile Platform Development
public class WeatherParser {
    private static final String LOG_TAG = "WeatherParser";

    public static List<Weather> parseWeatherData(InputStream inputStream) throws XmlPullParserException, IOException {
        List<Weather> weatherList = new ArrayList<>();

        XmlPullParser parser = XmlPullParserFactory.newInstance().newPullParser();
        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
        parser.setInput(inputStream, null);

        int eventType = parser.getEventType();
        Weather currentWeather = null;

        while (eventType != XmlPullParser.END_DOCUMENT) {
            String tagName = parser.getName();
            switch (eventType) {
                case XmlPullParser.START_TAG:
                    if ("item".equals(tagName)) {
                        currentWeather = new Weather("", "", "", 0.0, 0.0, 0, 0, 0, "", "", "");
                    } else if (currentWeather != null) {
                        extractWeatherDetails(currentWeather, tagName, parser.nextText());
                    }
                    break;
                case XmlPullParser.END_TAG:
                    if ("item".equals(tagName) && currentWeather != null) {
                        weatherList.add(currentWeather);
                        currentWeather = null;
                    }
                    break;
            }
            eventType = parser.next();
        }

        inputStream.close();
        return weatherList;
    }


    private static void extractWeatherDetails(Weather weather, String tagName, String value) {
        switch (tagName) {
            case "title":
                weather.setLocation(extractLocation(value));
                break;
            case "description":
                String[] minMaxTemperature = extractminTemperature(value);
                double minTemperature = Double.parseDouble(minMaxTemperature[0]);
                double maxTemperature = Double.parseDouble(minMaxTemperature[1]);
                double windSpeed = Double.parseDouble(extractWindSpeed(value));
                String temperature = extractTemperature(value);
                String weatherDescription = extractWeatherDescription(value);
                int humidity = extractHumidity(value);
                int uvRisk = extractUvRisk(value);
                String pollution = extractPollution(value);
                String sunrise = extractSunrise(value);
                String sunset = extractSunset(value);

                weather.setMinTemperature(minTemperature);
                weather.setMaxTemperature(maxTemperature);
                weather.setWindSpeed(windSpeed);
                weather.setTemperature(temperature);
                weather.setWeatherDescription(weatherDescription);
                weather.setHumidity(humidity);
                weather.setUvRisk(uvRisk);
                weather.setPollution(pollution);
                weather.setSunrise(sunrise);
                weather.setSunset(sunset);
                break;
        }
    }

    private static String readText(XmlPullParser parser) throws IOException, XmlPullParserException {
        String result = "";
        if (parser.next() == XmlPullParser.TEXT) {
            result = parser.getText();
            parser.nextTag();
        }
        return result;
    }


    // private static String extractLocation(String xml) {
    //String location = "";
        // Find the index of the image block
    //int startIndex = xml.indexOf("<image>");
    // int endIndex = xml.indexOf("</image>");
        // Extract the title tag within the image block
    // if (startIndex != -1 && endIndex != -1) {
    // String imageBlock = xml.substring(startIndex, endIndex);
    // int titleStartIndex = imageBlock.indexOf("<title>");
    //int titleEndIndex = imageBlock.indexOf("</title>");

    //if (titleStartIndex != -1 && titleEndIndex != -1) {
    //   location = imageBlock.substring(titleStartIndex + "<title>".length(), titleEndIndex).trim();
    //  Log.d("MyTag", "Extracted location: " + location);
    // }

    //}
    //return location;
    //}

    public static String extractLocation(String url) {
        String[] parts = url.split("/");
        String lastPart = parts[parts.length -1];
        return lastPart.replaceAll("[^\\d]", "");
    }


    private static String extractTemperature(String description) {
        String temperature = "";
        String[] parts = description.split(",");
        for (String part : parts) {
            if (part.trim().startsWith("Temperature:")) {
                temperature = part.trim().substring("Temperature:".length()).trim();
                Log.d("MyTag", "Extracted temperature: " + temperature);
                break;
            }
        }
        return temperature;
    }

    private static String[] extractminTemperature(String description) {
        String[] temperatureArray = new String[2];
        String[] parts = description.split(",");

        for (String part : parts) {
            if (part.trim().startsWith("Minimum Temperature:") || part.trim().startsWith("Maximum Temperature:")) {
                String temperature = part.trim().substring(part.indexOf(":") + 1).trim();
                // Remove unwanted characters and trim
                temperature = temperature.replaceAll("[^\\d.-]", "").trim();
                Log.d("MyTag", "Extracted temperature: " + temperature);

                if (!temperature.isEmpty()) {
                    if (part.trim().startsWith("Minimum Temperature:")) {
                        temperatureArray[0] = temperature;
                    } else {
                        temperatureArray[1] = temperature;
                    }
                }
            }
        }

        // Ensure both minimum and maximum temperatures are initialized
        if (temperatureArray[0] == null) {
            temperatureArray[0] = "0.0"; // Default value for minimum temperature
        }
        if (temperatureArray[1] == null) {
            temperatureArray[1] = "0.0"; // Default value for maximum temperature
        }

        return temperatureArray;
    }



    private static String extractWindSpeed(String description) {
        String windSpeed = "";
        String[] parts = description.split(",");
        for (String part : parts) {
            if (part.trim().startsWith("Wind Speed:")) {
                windSpeed = part.trim().substring("Wind Speed:".length()).trim();

                // Extract only numeric part (remove non-numeric characters)
                windSpeed = windSpeed.replaceAll("[^\\d.]", "");
                Log.d("MyTag", "Extracted windSpeed: " + windSpeed);

                break;
            }
        }
        return windSpeed;
    }


    private static String extractWeatherDescription(String description) {
        String weatherDescription = "";
        int todayIndex = description.indexOf("Today:");
        if (todayIndex != -1){
            String afterToday = description.substring(todayIndex + "Today:".length());
            afterToday = afterToday.trim();
            int commaIndex = afterToday.indexOf(',');
            if (commaIndex != -1) {
                weatherDescription = afterToday.substring(0, commaIndex).trim();
            } else {
                weatherDescription = afterToday;
            }
        }
        return weatherDescription;
    }

    private static int extractHumidity(String description) {
        int humidity = 0;
        String[] parts = description.split(",");
        for (String part : parts) {
            if (part.trim().startsWith("Humidity:")) {
                String humidtyStr = part.trim().substring("Humidity:".length()).trim();
                // Remove non-numeric characters
                humidtyStr = humidtyStr.replaceAll("[^\\d]", "");
                humidity = Integer.parseInt(humidtyStr);
                Log.d("MyTag", "Extracted Humidity: " + humidity);
                break;
            }
        }
        return humidity;
    }

    private static int extractUvRisk(String description) {
        int UvRisk = 0;
        String[] parts = description.split(",");
        for (String part : parts) {
            if (part.trim().startsWith("UV Risk:")) {
                UvRisk = Integer.parseInt(part.trim().substring("UV Risk:".length()).trim());
                Log.d("MyTag", "Extracted UvRisk: " + UvRisk);
                break;
            }
        }
        return UvRisk;
    }

    private static String extractPollution(String description) {
        String pollution = "";
        String[] parts = description.split(",");
        for (String part : parts) {
            if (part.trim().startsWith("Pollution:")) {
                pollution = part.trim().substring("Pollution:".length()).trim();
                Log.d("MyTag", "Extracted pollution: " + pollution);
                break;
            }
        }
        return pollution;
    }


    private static String extractSunrise(String description) {
        String sunrise = "";
        String[] parts = description.split(",");
        for (String part : parts) {
            if (part.trim().startsWith("Sunrise: ")) {
                sunrise = part.trim().substring("Sunrise: ".length()).trim();
                Log.d("MyTag", "Extracted sunrise: " + sunrise);
                break;
            }
        }
        return sunrise;
    }

    private static String extractSunset(String description) {
        String sunset = "";
        String[] parts = description.split(",");
        for (String part : parts) {
            if (part.trim().startsWith("Sunset: ")) {
                sunset = part.trim().substring("Sunset: ".length()).trim();
                Log.d("MyTag", "Extracted sunset: " + sunset);
                break;
            }
        }
        return sunset;
    }




    private static void skip(XmlPullParser parser) throws XmlPullParserException, IOException {
        if (parser.getEventType() != XmlPullParser.START_TAG) {
            throw new IllegalStateException();
        }
        int depth = 1;
        while (depth != 0) {
            switch (parser.next()) {
                case XmlPullParser.END_TAG:
                    depth--;
                    break;
                case XmlPullParser.START_TAG:
                    depth++;
                    break;
            }
        }
    }



}