package com.example.waithira_jane_s2110907;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WeatherAdapter extends RecyclerView.Adapter<WeatherAdapter.ViewHolder> {
    private List<Weather> weatherList;


    public WeatherAdapter(List<Weather> weatherList) {
        this.weatherList = weatherList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_weather, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Weather weather = weatherList.get(position);
        // Bind data to views in item_weather.xml
        holder.bind(weather);
    }

    @Override
    public int getItemCount() {
        return weatherList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private TextView temperatureText;
        private TextView locationText;
        private TextView windHumidityText;
        private TextView weatherDescriptionText;
        private ImageView weatherIconImage;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            temperatureText = itemView.findViewById(R.id.temperatureText);
            locationText = itemView.findViewById(R.id.locationText);
            windHumidityText = itemView.findViewById(R.id.windHumidityText);
            weatherDescriptionText = itemView.findViewById(R.id.weatherDescriptionText);
            weatherIconImage = itemView.findViewById(R.id.weatherIcon);
        }

        public void bind(Weather weather) {
            // Bind data to views
            temperatureText.setText(String.valueOf(weather.getTemperature()));
            locationText.setText(weather.getLocation());
            windHumidityText.setText(String.format("%s, %s", weather.getWindSpeed(), weather.getHumidity()));
            weatherDescriptionText.setText(weather.getWeatherDescription());
            // Set weather icon
            // weatherIconImage.setImageResource(R.drawable.weather_icon); // Set the appropriate weather icon
            Log.d("WeatherAdapter", "Temperature: " + weather.getTemperature());
            Log.d("WeatherAdapter", "Location: " + weather.getLocation());
            Log.d("WeatherAdapter", "Wind Speed: " + weather.getWindSpeed());
            Log.d("WeatherAdapter", "Humidity: " + weather.getHumidity());
            Log.d("WeatherAdapter", "Weather Description: " + weather.getWeatherDescription());

        }
    }
}
