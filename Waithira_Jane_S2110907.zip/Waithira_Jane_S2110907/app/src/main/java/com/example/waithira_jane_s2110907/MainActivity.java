package com.example.waithira_jane_s2110907;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.libraries.maps.model.LatLng;
import com.google.android.libraries.places.api.Places;
import com.google.maps.GeoApiContext;
import com.google.maps.GeocodingApi;
import com.google.maps.model.GeocodingResult;


import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import org.xmlpull.v1.XmlPullParserException;
import java.util.Map;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private RecyclerView weatherRecyclerView;
    private Button startButton;
    private WeatherAdapter weatherAdapter;
    private List<Weather> weatherList = new ArrayList<>();

    private Map<String, String> cityCodeToNameMap;

    private final String[] urlSource = {
            "https://weather-broker-cdn.api.bbci.co.uk/en/observation/rss/5128581",
            "https://weather-broker-cdn.api.bbci.co.uk/en/observation/rss/2648579",
            "https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/5128581",
            "https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/2648579 "
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize Google Maps Key
        String apiKey = getString(R.string.google_maps_key);
        if (!Places.isInitialized()) {
            Places.initialize(getApplicationContext(), apiKey);
        }


        weatherRecyclerView = findViewById(R.id.weatherRecyclerView);

        startButton = findViewById(R.id.startButton);
        startButton.setOnClickListener(this);

        // Create and set layout manager
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        weatherRecyclerView.setLayoutManager(layoutManager);

        // Create adapter and set to RecyclerView
        weatherAdapter = new WeatherAdapter(weatherList);
        weatherRecyclerView.setAdapter(weatherAdapter);
    }

    private void initializeCityCodeToMap(String cityCode){
       try {
           GeoApiContext context = new GeoApiContext.Builder()
                   .apiKey(getString(R.string.google_maps_key))
                   .build();

           // Get corresponding city name
           String cityName = getCityName(cityCode);

           //Perform geocoding to get lat and longitude
           GeocodingResult[] results = GeocodingApi.geocode(context, cityName).await();
           cityName = getCityName(cityCode);
           Log.d("MyTag", "City Name: " + cityName);


       } catch (Exception e) {
           e.printStackTrace();
       }

    }

    @Override
    public void onClick(View view) {
        startProgress();
        Log.d("MyTag", "Checking network connection...");
    }

    private void startProgress() {
        for (String url : urlSource) {
            String cityCode = WeatherParser.extractLocation(url);
            Log.d("MyTag", "City Code: " + cityCode);
            String cityName = getCityName(cityCode);
            Log.d("MyTag", "City Name: " + cityName);
            new Thread(new Task(url)).start();
        }
    }

    private String getCityName(String cityCode) {
        // If it exists, return city name
        //IF it does not exist, return unknown
        return cityCodeToNameMap.getOrDefault(cityCode, "Unknown");

    }

    private class Task implements Runnable {
        private final String url;
        private final StringBuilder result;

        public Task(String aurl) {
            url = aurl;
            result = new StringBuilder();
        }

        @Override
        public void run() {
            Log.d("MyTag", "Task run method called");
            StringBuilder result = new StringBuilder();

            URL aurl;
            URLConnection yc;
            BufferedReader in = null;
            String inputLine;

            Log.e("MyTag", "in run");

            try {
                Log.e("MyTag", "in try");
                aurl = new URL(url);
                yc = aurl.openConnection();
                in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
                while ((inputLine = in.readLine()) != null) {
                    result.append(inputLine);
                    //Log.d("MyTag","Received data from URL: " + inputLine);
                }
            } catch (IOException ae) {
                Log.e("MyTag", "IOException occurred while processing URL: " + url +  ": " + ae.getMessage());
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Error occurred. Please try again later.", Toast.LENGTH_SHORT).show());
            } finally {
                try {
                    if (in != null) {
                        in.close();
                    }
                } catch (IOException e) {
                    Log.e("MyTag", "Error closing BufferedReader: " + e.getMessage());
                }
            }
            processData(result.toString());
        }


        private void processData(String data) {
            try {
                ByteArrayInputStream inputStream = new ByteArrayInputStream(data.getBytes());
                List<Weather> newWeatherList = WeatherParser.parseWeatherData(inputStream);
                Log.d("MyTag", "Size of newWeatherList: " + newWeatherList.size());
                if (newWeatherList != null) {
                    updateUIWithWeatherData(newWeatherList);
                } else {
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Error parsing weather data.", Toast.LENGTH_SHORT).show());
                }
            } catch(XmlPullParserException | IOException e) {
                Log.e("MyTag", "Error processing data: " + e.getMessage());
                e.printStackTrace();
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Error occurred. Please try again later.", Toast.LENGTH_SHORT).show());
            }
        }


        private void updateUIWithWeatherData(final List<Weather> newWeatherList) {
            MainActivity.this.runOnUiThread(() -> {
                try {
                    if (!newWeatherList.isEmpty()) { // Check if the newWeatherList is not empty
                        // Clear existing data
                        weatherList.clear();
                        // Add new data
                        weatherList.addAll(newWeatherList);
                        // Notify adapter
                        weatherAdapter.notifyDataSetChanged(); // Update the existing adapter
                        Log.d("MyTag", "UI updated with weather information");
                    } else {
                        // Handle the case when newWeatherList is empty
                        Log.d("MyTag", "New weather list is empty");
                        // You can show a message to the user or handle this case as needed
                    }
                } catch (Exception e) {
                    Log.e("MyTag", "Exception occurred: " + e.getMessage());
                    e.printStackTrace();
                }
            });
        }
}
}
